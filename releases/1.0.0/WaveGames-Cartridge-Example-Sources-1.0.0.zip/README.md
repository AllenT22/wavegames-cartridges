# WaveGames first-party cartridge source

This archive contains the five API 1 example games and the exact dependency-free developer toolkit needed to test, simulate, validate, and pack them. Run the commands documented in `tools/wavegame/README.md` with Node.js 24 or newer.
